import React, { useState } from "react";
import { MOCK_CLINICIAN } from "../data/mockData";
import { NavView } from "../types";

interface TopHeaderProps {
  currentView: NavView;
  onMobileMenuToggle: () => void;
  onSearchChange?: (query: string) => void;
  onOpenNotifications?: () => void;
  onOpenHelp?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentView,
  onMobileMenuToggle,
  onSearchChange,
  onOpenNotifications,
  onOpenHelp,
}) => {
  const [searchValue, setSearchValue] = useState("");

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
    if (onSearchChange) {
      onSearchChange(e.target.value);
    }
  };

  return (
    <header className="bg-surface dark:bg-surface-dim top-0 h-16 sticky z-40 border-b border-outline-variant dark:border-outline flex justify-between items-center px-lg w-full max-w-container-max mx-auto md:px-xl">
      <div className="flex items-center gap-md">
        {/* Mobile Hamburger Menu */}
        <button
          onClick={onMobileMenuToggle}
          className="md:hidden text-primary cursor-pointer hover:text-on-surface-variant p-2 -ml-2 rounded-md hover:bg-surface-container-high transition-colors"
          aria-label="Toggle menu"
        >
          <span className="material-symbols-outlined">menu</span>
        </button>

        {/* Mobile Title */}
        <div className="md:hidden flex flex-col">
          <span className="font-headline-sm text-headline-sm font-bold text-primary dark:text-primary-fixed">
            MediDiet AI
          </span>
        </div>

        {/* Desktop Header Search Field (when in Patients or General context) */}
        <div className="relative w-64 md:w-80 hidden sm:block">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline-variant text-[20px]">
            search
          </span>
          <input
            type="text"
            value={searchValue}
            onChange={handleSearchInput}
            placeholder="Search patients, diets, labs..."
            className="w-full bg-surface-container-low border border-outline-variant/50 rounded-full py-2 pl-10 pr-4 font-body-sm text-body-sm text-on-surface focus:ring-2 focus:ring-primary focus:bg-surface-container-lowest transition-colors placeholder:text-outline"
          />
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-4 text-on-surface-variant">
        {/* Notifications Button with Red Badge */}
        <button
          onClick={onOpenNotifications}
          className="relative hover:text-primary cursor-pointer active:scale-95 transition-transform p-2 rounded-full hover:bg-surface-container-high border border-transparent"
          title="Notifications"
        >
          <span className="material-symbols-outlined">notifications</span>
          <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-error rounded-full ring-2 ring-surface"></span>
        </button>

        {/* Help Button */}
        <button
          onClick={onOpenHelp}
          className="hover:text-primary cursor-pointer active:scale-95 transition-transform p-2 rounded-full hover:bg-surface-container-high hidden sm:flex border border-transparent"
          title="Clinical Documentation & Support"
        >
          <span className="material-symbols-outlined">help_outline</span>
        </button>

        {/* Clinician Profile Avatar */}
        <div className="flex items-center gap-2 pl-2 border-l border-outline-variant/60">
          <img
            src={MOCK_CLINICIAN.avatarUrl}
            alt={MOCK_CLINICIAN.name}
            className="w-8 h-8 md:w-9 md:h-9 rounded-full object-cover border border-outline-variant"
          />
          <span className="font-body-sm text-body-sm font-semibold text-on-surface hidden lg:inline">
            Dr. Sarah Jenkins
          </span>
        </div>
      </div>
    </header>
  );
};
